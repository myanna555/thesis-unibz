<?php
// Silence is golden. We also agree :)
?>